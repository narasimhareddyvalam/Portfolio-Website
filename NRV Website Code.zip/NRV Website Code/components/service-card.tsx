"use client"

import { Tilt } from "react-tilt"
import { Card, CardContent } from "@/components/ui/card"
import type { ReactNode } from "react"

interface Service {
  id: number
  title: string
  description: string
  icon: ReactNode
  color: string
}

interface ServiceCardProps {
  service: Service
}

export default function ServiceCard({ service }: ServiceCardProps) {
  const defaultTiltOptions = {
    reverse: false,
    max: 15,
    perspective: 1000,
    scale: 1.05,
    speed: 1000,
    transition: true,
    axis: null,
    reset: true,
    easing: "cubic-bezier(.03,.98,.52,.99)",
  }

  return (
    <Tilt options={defaultTiltOptions}>
      <Card className="group h-[320px] bg-[#161616] border-0 overflow-hidden rounded-xl shadow-lg hover:shadow-xl transition-all duration-300">
        <CardContent className="p-8 flex flex-col h-full items-center">
          <div
            className={`w-16 h-16 rounded-xl mb-6 flex items-center justify-center bg-gradient-to-r ${service.color} text-[#0E0E0E]`}
          >
            {service.icon}
          </div>

          <h3 className="text-xl font-bold mb-3 text-[#BC9862] group-hover:translate-x-2 transition-transform duration-300 text-center">
            {service.title}
          </h3>

          <p className="text-[#DAC5A7]/80 flex-grow text-center">{service.description}</p>
        </CardContent>
      </Card>
    </Tilt>
  )
}

