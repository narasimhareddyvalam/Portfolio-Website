"use client"

import { motion } from "framer-motion"
import CertificateCard from "@/components/certificate-card"

export default function CertificationsSection() {
  const certificates = [
    {
      id: 1,
      title: "Certified Pega Business Architect",
      issuer: "Pega",
      date: "2023",
      image: "/images/pega-business-architect.jpeg",
      description: "Focused on designing business solutions using Pega's visual tools.",
      link: "https://academy.pega.com/verify-certification?email=narasimha.valam%40gmail.com",
    },
    {
      id: 2,
      title: "Certified Pega System Architect",
      issuer: "Pega",
      date: "2023",
      image: "/images/pega-system-architect.jpeg",
      description: "Validates hands-on ability to build applications using Pega Platform.",
      link: "https://academy.pega.com/verify-certification?email=narasimha.valam%40gmail.com",
    },
    {
      id: 3,
      title: "Certified Salesforce Associate",
      issuer: "Salesforce",
      date: "2023",
      image: "/images/salesforce-associate.jpeg",
      description: "Demonstrates foundational Salesforce knowledge, including CRM basics and navigation.",
      link: "https://trailhead.salesforce.com/en/credentials/verification/",
    },
    {
      id: 4,
      title: "Certified Salesforce Administrator",
      issuer: "Salesforce",
      date: "2024",
      image: "/images/salesforce-admin.jpeg",
      description: "Covers automation, security, data models, and platform configuration in Salesforce.",
      link: "https://trailhead.salesforce.com/en/credentials/verification/",
    },
  ]

  return (
    <section id="certifications" className="relative py-32">
      <div className="container max-w-6xl mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true, margin: "-100px" }}
          className="mb-16 text-center"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6 text-[#BC9862]">Certifications</h2>
          <p className="text-xl max-w-2xl mx-auto text-[#DAC5A7]/80">
            Credentials that back up my expertise and continuous learning journey.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {certificates.map((certificate, index) => (
            <motion.div
              key={certificate.id}
              initial={{ opacity: 0, y: 50, rotateY: 30 }}
              whileInView={{ opacity: 1, y: 0, rotateY: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true, margin: "-100px" }}
            >
              <CertificateCard certificate={certificate} />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

