"use client"

import { useState } from "react"
import Image from "next/image"
import { motion } from "framer-motion"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ExternalLink } from "lucide-react"

interface Certificate {
  id: number
  title: string
  issuer: string
  date: string
  image: string
  description?: string
  link: string
}

interface CertificateCardProps {
  certificate: Certificate
}

export default function CertificateCard({ certificate }: CertificateCardProps) {
  const [isFlipped, setIsFlipped] = useState(false)

  return (
    <div className="h-[450px] perspective-1000">
      <motion.div
        className="relative w-full h-full transition-all duration-500 preserve-3d cursor-pointer"
        animate={{ rotateY: isFlipped ? 180 : 0 }}
        onClick={() => setIsFlipped(!isFlipped)}
      >
        {/* Front of card */}
        <div className="absolute w-full h-full backface-hidden">
          <Card className="w-full h-full bg-[#161616] border-0 overflow-hidden rounded-xl shadow-lg hover:shadow-[0_0_25px_rgba(188,152,98,0.15)] transition-all duration-300">
            <div className="relative h-60 overflow-hidden">
              <Image
                src={certificate.image || "/placeholder.svg"}
                alt={certificate.title}
                fill
                className="object-cover"
                priority
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#161616] to-transparent"></div>
            </div>
            <div className="p-8">
              <h3 className="text-lg font-bold mb-1 text-[#BC9862]">{certificate.title}</h3>
              <p className="text-[#DAC5A7]/70 mb-4">
                {certificate.issuer} • {certificate.date}
              </p>
              <Button
                size="md"
                variant="outline"
                className="border-[#BC9862] text-[#BC9862] hover:bg-[#BC9862]/10 text-base px-6 py-2 mt-2"
              >
                <span>Flip to view details</span>
              </Button>
            </div>
          </Card>
        </div>

        {/* Back of card */}
        <div className="absolute w-full h-full backface-hidden rotate-y-180">
          <Card className="w-full h-full bg-[#161616] border-0 overflow-hidden rounded-xl shadow-lg flex flex-col justify-center items-center p-6 text-center">
            <h3 className="text-lg font-bold mb-4 text-[#BC9862]">{certificate.title}</h3>
            <p className="text-[#DAC5A7]/90 mb-6">
              {certificate.description ||
                `This certification validates expertise in ${certificate.title.toLowerCase()} principles and best practices.`}
            </p>
            <div className="mt-auto">
              <Button size="sm" className="bg-[#BC9862] text-[#0E0E0E] hover:bg-[#BC9862]/90 mr-2" asChild>
                <a href={certificate.link} target="_blank" rel="noopener noreferrer">
                  <ExternalLink className="h-4 w-4 mr-2" />
                  View Certificate
                </a>
              </Button>
              <Button
                size="sm"
                variant="outline"
                className="border-[#BC9862] text-[#BC9862] hover:bg-[#BC9862]/10 mt-2"
                onClick={(e) => {
                  e.stopPropagation()
                  setIsFlipped(false)
                }}
              >
                <span>Flip Back</span>
              </Button>
            </div>
          </Card>
        </div>
      </motion.div>
    </div>
  )
}

