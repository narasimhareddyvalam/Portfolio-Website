"use client"

import { useRef } from "react"
import { motion, useTransform, useScroll } from "framer-motion"
import ProjectCard from "@/components/project-card"

export default function ProjectsSection() {
  const projectsRef = useRef(null)
  const { scrollYProgress } = useScroll()
  const projectsY = useTransform(scrollYProgress, [0.3, 0.5], [100, 0])

  const projects = [
    {
      id: 1,
      title: "Microbial Threat Detection",
      subtitle: "Bluevoir Technologies",
      description: "Advanced system for detecting and analyzing microbial threats using AI and automation workflows.",
      image: "/images/microbial-threat-detection.jpeg",
      tags: ["Pega", "GenAI", "Automation", "Data Modeling"],
      tools: ["Pega", "GenAI", "Data Types", "Decision Tables"],
      achievements: [
        "Used Pega GenAI Blueprint to design and automate workflows",
        "Built custom data models using Data Types and Data Pages",
        "Implemented decision tables to improve process performance",
        "Collaborated with stakeholders to gather and translate business requirements",
      ],
      link: "https://medium.com/@valam.n/microbial-threat-detection-the-ai-driven-defense-against-invisible-killers-d904f415b92b",
      color: "from-[#BC9862] to-amber-500",
    },
    {
      id: 2,
      title: "HR Management System",
      subtitle: "Bluevoir Technologies",
      description:
        "Comprehensive HR management system with automated workflows and smart decision-making capabilities.",
      image: "/images/hr-management-system.jpeg",
      tags: ["HR", "Automation", "Process Modeling", "Collaboration"],
      tools: ["Pega", "Visual Modeling", "Delegated Rules", "Workflow"],
      achievements: [
        "Designed HR process flows using Pega visual modeling",
        "Built delegated rules for unpaid leave thresholds",
        "Collaborated across business & tech teams to implement smart HR automation",
      ],
      link: "https://medium.com/@valam.n/i-tamed-hr-chaos-with-pega-and-made-it-fun-yes-really-c753cc62f4f0",
      color: "from-rose-500 to-pink-500",
    },
    {
      id: 3,
      title: "Stor-a-genic Bot",
      subtitle: "Conversational AI Solution",
      description:
        "An intelligent chatbot that simplifies storage pickup scheduling and provides instant answers to customer queries.",
      image: "/images/stor-a-genic-bot.png",
      tags: ["Chatbot", "AI", "UX Design", "API Integration"],
      tools: ["Flask", "NLP", "REST API", "Python"],
      achievements: [
        "Implemented a conversational booking system that collects user details (name, address, date/time) and sends them to a backend system",
        "Built an FAQ system that provides instant answers to common questions via API calls",
        "Designed error recovery flows with friendly fallback messages and retry options",
        "Created a natural conversation flow with micro-humor and emojis for improved UX",
        "Developed intent recognition to keep conversations on track and handle global intents",
      ],
      features: [
        {
          title: "Book a Pickup Instantly",
          description:
            "Users can easily schedule a storage pickup by simply chatting with the bot. The bot collects full name, pickup address, and preferred date & time, then sends the information directly to a backend system.",
        },
        {
          title: "Get Instant Answers (FAQ System)",
          description:
            "Users can ask questions about costs, service areas, or cancellations. The bot fetches accurate responses using a GET request to a preloaded FAQ database.",
        },
        {
          title: "Recover from Errors with Ease",
          description:
            "If a user gives incomplete or invalid info, the bot responds with friendly fallback messages, retry options, and clarification prompts.",
        },
        {
          title: "Enjoy a Friendly Conversation Flow",
          description: "Messages are kept short, engaging, and human-like with micro-humor and emojis for a warm UX.",
        },
        {
          title: "Stay on Track with Intent Recognition",
          description:
            "Recognizes user intent and reroutes the conversation accordingly, including global intents for logging expenses, getting tips, and checking balances.",
        },
      ],
      link: "#",
      color: "from-blue-500 to-cyan-500",
    },
  ]

  return (
    <section id="projects" ref={projectsRef} className="relative py-32 bg-[#0E0E0E]/50">
      <motion.div className="container max-w-6xl mx-auto px-4" style={{ y: projectsY }}>
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true, margin: "-100px" }}
          className="mb-16 text-center"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6 text-[#BC9862]">Featured Projects</h2>
          <p className="text-xl max-w-2xl mx-auto text-[#DAC5A7]/80">
            A showcase of selected projects where creativity meets functionality.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:max-w-4xl mx-auto">
          {projects.map((project, index) => (
            <motion.div
              key={project.id}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              viewport={{ once: true, margin: "-100px" }}
            >
              <ProjectCard project={project} />
            </motion.div>
          ))}
        </div>
      </motion.div>
    </section>
  )
}

