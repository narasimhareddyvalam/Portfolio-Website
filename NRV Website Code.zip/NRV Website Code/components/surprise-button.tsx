"use client"

import { Sparkles } from "lucide-react"
import confetti from "canvas-confetti"

export default function SurpriseButton({ triggerSurprise }: { triggerSurprise: () => void }) {
  const handleSurprise = () => {
    // Enhanced confetti effect
    const randomConfetti = () => {
      const colors = ["#BC9862", "#DAC5A7", "#f5a623", "#f8e71c"]

      // Multiple confetti bursts
      confetti({
        particleCount: 150,
        spread: 100,
        origin: { y: 0.6, x: Math.random() },
        colors: colors,
        shapes: ["circle", "square"],
        ticks: 200,
      })

      // Side confetti
      setTimeout(() => {
        confetti({
          particleCount: 80,
          angle: 60,
          spread: 70,
          origin: { x: 0 },
          colors: colors,
        })

        confetti({
          particleCount: 80,
          angle: 120,
          spread: 70,
          origin: { x: 1 },
          colors: colors,
        })
      }, 250)
    }

    randomConfetti()
    triggerSurprise()
  }

  return (
    <button
      onClick={handleSurprise}
      className="fixed bottom-6 right-6 z-50 px-4 py-2 rounded-full bg-[#BC9862] text-[#0E0E0E] font-medium hover:bg-[#BC9862]/90 hover:scale-105 transition-all duration-300 flex items-center space-x-2 shadow-lg hover:shadow-[#BC9862]/20 hover:shadow-xl"
    >
      <span>Surprise Me</span>
      <Sparkles className="h-4 w-4" />
    </button>
  )
}

