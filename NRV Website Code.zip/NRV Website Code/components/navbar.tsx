"use client"

import type React from "react"

import Link from "next/link"

export default function Navbar() {
  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, id: string) => {
    e.preventDefault()
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" })
  }

  return (
    <header className="sticky top-0 z-40 backdrop-blur-lg bg-[#0E0E0E]/70 border-b border-[#BC9862]/20">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <Link href="/" className="text-xl font-bold text-[#BC9862]">
          <span>Valam</span>
        </Link>
        <nav className="hidden md:flex space-x-6">
          <Link
            href="#services"
            className="hover:text-[#BC9862] transition-colors"
            onClick={(e) => handleNavClick(e, "services")}
          >
            Services
          </Link>
          <Link
            href="#projects"
            className="hover:text-[#BC9862] transition-colors"
            onClick={(e) => handleNavClick(e, "projects")}
          >
            Projects
          </Link>
          <Link
            href="#certifications"
            className="hover:text-[#BC9862] transition-colors"
            onClick={(e) => handleNavClick(e, "certifications")}
          >
            Certifications
          </Link>
          <Link
            href="#about"
            className="hover:text-[#BC9862] transition-colors"
            onClick={(e) => handleNavClick(e, "about")}
          >
            About
          </Link>
          <Link
            href="#contact"
            className="hover:text-[#BC9862] transition-colors"
            onClick={(e) => handleNavClick(e, "contact")}
          >
            Contact
          </Link>
        </nav>
      </div>
    </header>
  )
}

