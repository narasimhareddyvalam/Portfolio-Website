"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Sparkles } from "lucide-react"

export default function PageLoader() {
  const [loadingPhase, setLoadingPhase] = useState(0)
  const loadingTexts = ["Injecting Vibes...", "Preparing Brilliance...", "Unleashing Valam..."]

  useEffect(() => {
    const timer1 = setTimeout(() => setLoadingPhase(1), 1000)
    const timer2 = setTimeout(() => setLoadingPhase(2), 2000)

    return () => {
      clearTimeout(timer1)
      clearTimeout(timer2)
    }
  }, [])

  return (
    <div className="fixed inset-0 bg-[#0E0E0E] z-50 flex flex-col items-center justify-center">
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="relative"
      >
        <Sparkles className="h-16 w-16 text-[#BC9862] animate-pulse" />
        <motion.div
          className="absolute inset-0 rounded-full bg-[#BC9862]/20 blur-xl"
          animate={{ scale: [1, 1.2, 1] }}
          transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
        />
      </motion.div>

      <div className="h-20 mt-8">
        <AnimatePresence mode="wait">
          <motion.div
            key={loadingPhase}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.5 }}
            className="text-2xl font-bold text-[#BC9862]"
          >
            {loadingTexts[loadingPhase]}
          </motion.div>
        </AnimatePresence>
      </div>

      <motion.div
        className="w-64 h-1 bg-[#161616] rounded-full mt-8 overflow-hidden"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
      >
        <motion.div
          className="h-full bg-gradient-to-r from-[#BC9862] to-amber-500"
          initial={{ width: "0%" }}
          animate={{ width: "100%" }}
          transition={{ duration: 3, ease: "easeInOut" }}
        />
      </motion.div>
    </div>
  )
}

