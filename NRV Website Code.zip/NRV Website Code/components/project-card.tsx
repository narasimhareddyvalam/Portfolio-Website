"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { Tilt } from "react-tilt"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent } from "@/components/ui/dialog"
import { ExternalLink, X } from "lucide-react"

interface Project {
  id: number
  title: string
  subtitle: string
  description: string
  image: string
  tags: string[]
  tools: string[]
  achievements?: string[]
  features?: {
    title: string
    description: string
  }[]
  link: string
  color: string
}

interface ProjectCardProps {
  project: Project
}

export default function ProjectCard({ project }: ProjectCardProps) {
  const [isOpen, setIsOpen] = useState(false)

  // Add this effect to ensure cursor is visible when dialog is open
  useEffect(() => {
    if (isOpen) {
      document.body.classList.add("dialog-open")
    } else {
      document.body.classList.remove("dialog-open")
    }

    return () => {
      document.body.classList.remove("dialog-open")
    }
  }, [isOpen])

  const defaultTiltOptions = {
    reverse: false,
    max: 15,
    perspective: 1000,
    scale: 1.05,
    speed: 1000,
    transition: true,
    axis: null,
    reset: true,
    easing: "cubic-bezier(.03,.98,.52,.99)",
  }

  // Determine if we should show the buttons based on project title
  const showFindMoreButton = !["Microbial Threat Detection", "HR Management System", "Stor-a-genic Bot"].includes(
    project.title,
  )
  const showVisitLiveButton = !["Stor-a-genic Bot"].includes(project.title)

  return (
    <>
      <Tilt options={defaultTiltOptions}>
        <Card
          className="group relative overflow-hidden border-0 bg-[#161616] rounded-xl shadow-xl h-full cursor-pointer"
          onClick={() => setIsOpen(true)}
        >
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-[#0E0E0E]/90 z-10"></div>

          <div className="relative h-80 overflow-hidden">
            <Image
              src={project.image || "/placeholder.svg"}
              alt={project.title}
              fill
              className="object-cover transition-transform duration-700 group-hover:scale-110"
              priority
            />
            <div
              className={`absolute inset-0 bg-gradient-to-r ${project.color} opacity-0 group-hover:opacity-20 transition-all duration-300 z-0`}
            ></div>
          </div>

          <div className="relative z-20 p-8">
            <div className="mb-2">
              <span className="text-sm font-medium text-[#BC9862]">{project.subtitle}</span>
            </div>
            <h3 className="text-3xl font-bold mb-3 text-[#BC9862] group-hover:translate-x-2 transition-transform duration-300">
              {project.title}
            </h3>

            <p className="text-[#DAC5A7]/90 mb-6 line-clamp-2">{project.description}</p>

            <div className="flex flex-wrap gap-2 mb-6">
              {project.tags.slice(0, 3).map((tag) => (
                <Badge
                  key={tag}
                  className="bg-[#BC9862]/20 text-[#BC9862] hover:bg-[#BC9862]/30 border border-[#BC9862]/30"
                >
                  {tag}
                </Badge>
              ))}
              {project.tags.length > 3 && (
                <Badge className="bg-[#161616] text-[#DAC5A7] hover:bg-[#161616]/80">+{project.tags.length - 3}</Badge>
              )}
            </div>

            <div className="flex items-center justify-between">
              <div className="flex -space-x-2">
                {project.tools.slice(0, 3).map((tool, index) => (
                  <div
                    key={tool}
                    className="w-8 h-8 rounded-full bg-[#161616] border-2 border-[#161616] flex items-center justify-center text-xs font-bold shadow-sm"
                    style={{ zIndex: 10 - index }}
                  >
                    {/* Don't show the initial letter */}
                  </div>
                ))}
              </div>

              <Button
                size="sm"
                className="bg-[#BC9862] text-[#0E0E0E] hover:bg-[#BC9862]/90 opacity-0 group-hover:opacity-100 transition-opacity"
              >
                View Details
              </Button>
            </div>
          </div>
        </Card>
      </Tilt>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-w-3xl bg-[#161616] border-0 p-0 rounded-xl overflow-hidden">
          <button
            onClick={() => setIsOpen(false)}
            className="absolute top-4 right-4 z-50 p-2 rounded-full bg-[#0E0E0E]/80 border border-[#BC9862]/30"
          >
            <X className="h-4 w-4 text-[#DAC5A7]" />
          </button>

          <div className="relative h-64 overflow-hidden">
            <Image
              src={project.image || "/placeholder.svg"}
              alt={project.title}
              fill
              className="object-cover"
              priority
            />
            <div className={`absolute inset-0 bg-gradient-to-b from-transparent to-[#161616]/90`}></div>

            <div className="absolute bottom-0 left-0 right-0 p-6">
              <span className="text-sm font-medium text-[#BC9862]">{project.subtitle}</span>
              <h2 className="text-2xl font-bold text-[#BC9862]">{project.title}</h2>
            </div>
          </div>

          <div className="p-6">
            <div className="flex flex-wrap gap-2 mb-4">
              {project.tags.map((tag) => (
                <Badge
                  key={tag}
                  className="bg-[#BC9862]/20 text-[#BC9862] hover:bg-[#BC9862]/30 border border-[#BC9862]/30"
                >
                  {tag}
                </Badge>
              ))}
            </div>

            <p className="text-[#DAC5A7]/90 mb-6 text-sm">{project.description}</p>

            {project.achievements && (
              <div className="mb-6">
                <h3 className="text-base font-bold mb-2 text-[#BC9862]">Key Achievements</h3>
                <ul className="space-y-1 text-sm">
                  {project.achievements.map((achievement, index) => (
                    <li key={index} className="flex items-start">
                      <span className="text-[#BC9862] mr-2">•</span>
                      <span className="text-[#DAC5A7]/90">{achievement}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            <div className="mb-6">
              <h3 className="text-base font-bold mb-2 text-[#BC9862]">Tools & Technologies</h3>
              <div className="flex flex-wrap gap-2">
                {project.tools.map((tool) => (
                  <Badge
                    key={tool}
                    className="bg-amber-900/20 text-amber-500 hover:bg-amber-900/30 border border-amber-900/30"
                  >
                    {tool}
                  </Badge>
                ))}
              </div>
            </div>

            <div className="flex justify-end space-x-3">
              {showVisitLiveButton && (
                <Button size="sm" className="bg-[#BC9862] text-[#0E0E0E] hover:bg-[#BC9862]/90" asChild>
                  <a href={project.link} target="_blank" rel="noopener noreferrer">
                    <ExternalLink className="h-3 w-3 mr-2" />
                    Visit Project
                  </a>
                </Button>
              )}

              {showFindMoreButton && (
                <Button size="sm" variant="outline" className="border-[#BC9862] text-[#BC9862] hover:bg-[#BC9862]/10">
                  Find More
                </Button>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  )
}

