"use client"

export default function Footer({ triggerSurprise }: { triggerSurprise: () => void }) {
  return (
    <footer className="relative py-12 border-t border-[#BC9862]/20">
      <div className="container mx-auto px-4 text-center">
        <p className="text-[#DAC5A7]/60 mb-4">
          © {new Date().getFullYear()} Narasimha Reddy Valam | Low Code Solutions Architect
        </p>
        <p className="text-[#DAC5A7]/40 text-sm">Built with lot of ✨ creative energy ✨</p>
        <div
          className="mt-6 text-xs text-[#BC9862]/40 hover:text-[#BC9862]/60 transition-colors cursor-pointer"
          onClick={triggerSurprise}
        >
          <span>Psst... there are hidden surprises throughout this site!</span>
        </div>
      </div>
    </footer>
  )
}

