"use client"

import type React from "react"

import { useRef, useState } from "react"
import { motion, useTransform, useScroll } from "framer-motion"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Mail, Github, Linkedin, CheckCircle, AlertCircle } from "lucide-react"
import { toast } from "@/components/ui/use-toast"

export default function ContactSection() {
  const contactRef = useRef(null)
  const { scrollYProgress } = useScroll()
  const contactY = useTransform(scrollYProgress, [0.7, 0.9], [100, 0])

  const [formState, setFormState] = useState({
    name: "",
    email: "",
    message: "",
  })

  const [isSubmitting, setIsSubmitting] = useState(false)
  const [formStatus, setFormStatus] = useState<null | "success" | "error">(null)

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { id, value } = e.target
    setFormState((prev) => ({
      ...prev,
      [id]: value,
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    // Basic validation
    if (!formState.name || !formState.email || !formState.message) {
      toast({
        title: "Missing Information",
        description: "Please fill in all fields before submitting.",
        variant: "destructive",
      })
      return
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(formState.email)) {
      toast({
        title: "Invalid Email",
        description: "Please enter a valid email address.",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      // Simulate form submission
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // Success
      setFormStatus("success")
      toast({
        title: "Message Sent!",
        description: "Thank you for reaching out. I'll get back to you soon!",
      })

      // Reset form
      setFormState({
        name: "",
        email: "",
        message: "",
      })

      // Reset status after a delay
      setTimeout(() => {
        setFormStatus(null)
      }, 3000)
    } catch (error) {
      setFormStatus("error")
      toast({
        title: "Something went wrong",
        description: "Please try again later or contact me directly via email.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <section id="contact" ref={contactRef} className="relative py-32">
      <motion.div className="container max-w-4xl mx-auto px-4" style={{ y: contactY }}>
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true, margin: "-100px" }}
          className="mb-16 text-center"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6 text-[#BC9862]">Let's Make Something Wild</h2>
          <p className="text-xl max-w-2xl mx-auto text-[#DAC5A7]/80">
            If you've scrolled this far, Let's Geek Out on Tech!
          </p>
        </motion.div>

        <Card className="bg-[#161616] border-0 rounded-xl overflow-hidden shadow-2xl">
          <div className="p-8 md:p-12">
            <form className="space-y-6" onSubmit={handleSubmit}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label htmlFor="name" className="block text-sm font-medium text-[#BC9862]">
                    Name
                  </label>
                  <input
                    type="text"
                    id="name"
                    value={formState.name}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 bg-[#0E0E0E]/80 border border-[#BC9862]/30 rounded-md focus:outline-none focus:ring-2 focus:ring-[#BC9862]/50 text-[#DAC5A7] transition-all"
                    placeholder="Your name"
                  />
                </div>
                <div className="space-y-2">
                  <label htmlFor="email" className="block text-sm font-medium text-[#BC9862]">
                    Email
                  </label>
                  <input
                    type="email"
                    id="email"
                    value={formState.email}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 bg-[#0E0E0E]/80 border border-[#BC9862]/30 rounded-md focus:outline-none focus:ring-2 focus:ring-[#BC9862]/50 text-[#DAC5A7] transition-all"
                    placeholder="your.email@example.com"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label htmlFor="message" className="block text-sm font-medium text-[#BC9862]">
                  Message
                </label>
                <textarea
                  id="message"
                  rows={5}
                  value={formState.message}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 bg-[#0E0E0E]/80 border border-[#BC9862]/30 rounded-md focus:outline-none focus:ring-2 focus:ring-[#BC9862]/50 text-[#DAC5A7] transition-all"
                  placeholder="Tell me about your project..."
                ></textarea>
              </div>
              <Button
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-[#BC9862] text-[#0E0E0E] hover:bg-[#BC9862]/90 py-6 text-lg relative overflow-hidden group"
              >
                <span className="relative z-10 flex items-center justify-center">
                  {isSubmitting ? "Sending..." : "Send Message"}
                  {formStatus === "success" && <CheckCircle className="ml-2 h-5 w-5" />}
                  {formStatus === "error" && <AlertCircle className="ml-2 h-5 w-5" />}
                </span>
                <span className="absolute inset-0 h-full w-0 bg-[#0E0E0E]/20 group-hover:w-full transition-all duration-300"></span>
              </Button>
            </form>

            <div className="mt-12">
              <div className="flex justify-center space-x-8">
                <motion.a
                  href="mailto:valam.n@northeastern.edu"
                  whileHover={{ scale: 1.2, rotate: 5 }}
                  whileTap={{ scale: 0.9 }}
                  className="text-[#BC9862] hover:text-[#DAC5A7] transition-colors"
                >
                  <Mail className="h-8 w-8" />
                  <span className="sr-only">Email</span>
                </motion.a>
                <motion.a
                  href="https://github.com/narasimhareddyvalam?tab=repositories"
                  target="_blank"
                  rel="noopener noreferrer"
                  whileHover={{ scale: 1.2, rotate: -5 }}
                  whileTap={{ scale: 0.9 }}
                  className="text-[#BC9862] hover:text-[#DAC5A7] transition-colors"
                >
                  <Github className="h-8 w-8" />
                  <span className="sr-only">GitHub</span>
                </motion.a>
                <motion.a
                  href="https://www.linkedin.com/in/narasimha-reddy-valam-739b54289/"
                  target="_blank"
                  rel="noopener noreferrer"
                  whileHover={{ scale: 1.2, rotate: 5 }}
                  whileTap={{ scale: 0.9 }}
                  className="text-[#BC9862] hover:text-[#DAC5A7] transition-colors"
                >
                  <Linkedin className="h-8 w-8" />
                  <span className="sr-only">LinkedIn</span>
                </motion.a>
              </div>
            </div>
          </div>
        </Card>
      </motion.div>
    </section>
  )
}

