"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"

export default function CustomCursor() {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 })
  const [cursorVariant, setCursorVariant] = useState("default")
  const [isEnabled, setIsEnabled] = useState(false) // Start with cursor disabled until we confirm desktop
  const [isDialogOpen, setIsDialogOpen] = useState(false)

  useEffect(() => {
    // Only enable custom cursor on desktop after component mounts
    if (typeof window !== "undefined" && window.innerWidth >= 1024) {
      setIsEnabled(true)
    }

    const mouseMove = (e: MouseEvent) => {
      setMousePosition({
        x: e.clientX,
        y: e.clientY,
      })
    }

    const mouseDown = () => setCursorVariant("click")
    const mouseUp = () => setCursorVariant("default")

    const handleLinkHover = () => setCursorVariant("hover")
    const handleButtonHover = () => setCursorVariant("button")
    const handleImageHover = () => setCursorVariant("view")
    const handleDefaultLeave = () => setCursorVariant("default")

    window.addEventListener("mousemove", mouseMove)
    window.addEventListener("mousedown", mouseDown)
    window.addEventListener("mouseup", mouseUp)

    const links = document.querySelectorAll("a")
    const buttons = document.querySelectorAll("button")
    const images = document.querySelectorAll("img")

    links.forEach((link) => {
      link.addEventListener("mouseenter", handleLinkHover)
      link.addEventListener("mouseleave", handleDefaultLeave)
    })

    buttons.forEach((button) => {
      button.addEventListener("mouseenter", handleButtonHover)
      button.addEventListener("mouseleave", handleDefaultLeave)
    })

    images.forEach((image) => {
      image.addEventListener("mouseenter", handleImageHover)
      image.addEventListener("mouseleave", handleDefaultLeave)
    })

    // Check for dialogs immediately on mount
    const checkForDialogs = () => {
      const dialogOpen = document.querySelector('[role="dialog"][data-state="open"]')
      if (dialogOpen) {
        document.body.classList.add("dialog-open")
        setIsDialogOpen(true)
      } else {
        document.body.classList.remove("dialog-open")
        setIsDialogOpen(false)
      }
    }

    checkForDialogs()

    // Function to observe DOM changes for dialog elements
    const observeDialogs = () => {
      const observer = new MutationObserver((mutations) => {
        checkForDialogs()
      })

      // Start observing the document with the configured parameters
      observer.observe(document.body, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ["data-state"],
      })

      return observer
    }

    const observer = observeDialogs()

    return () => {
      window.removeEventListener("mousemove", mouseMove)
      window.removeEventListener("mousedown", mouseDown)
      window.removeEventListener("mouseup", mouseUp)

      links.forEach((link) => {
        link.removeEventListener("mouseenter", handleLinkHover)
        link.removeEventListener("mouseleave", handleDefaultLeave)
      })

      buttons.forEach((button) => {
        button.removeEventListener("mouseenter", handleButtonHover)
        button.removeEventListener("mouseleave", handleDefaultLeave)
      })

      images.forEach((image) => {
        image.removeEventListener("mouseenter", handleImageHover)
        image.removeEventListener("mouseleave", handleDefaultLeave)
      })

      if (observer) {
        observer.disconnect()
      }
    }
  }, [])

  // Spotlight size variations based on cursor state
  const getSpotlightSize = () => {
    switch (cursorVariant) {
      case "hover":
        return 350
      case "button":
        return 400
      case "view":
        return 450
      case "click":
        return 300
      default:
        return 300
    }
  }

  // Don't render if not enabled
  if (!isEnabled) {
    return null
  }

  return (
    <>
      {/* Spotlight effect */}
      <motion.div
        className="fixed top-0 left-0 pointer-events-none z-[9997]"
        style={{
          x: mousePosition.x - getSpotlightSize() / 2,
          y: mousePosition.y - getSpotlightSize() / 2,
          height: getSpotlightSize(),
          width: getSpotlightSize(),
          borderRadius: "50%",
          background: "radial-gradient(circle, rgba(188, 152, 98, 0.15) 0%, rgba(188, 152, 98, 0) 70%)",
        }}
        transition={{
          type: "spring",
          mass: 0.1,
          stiffness: 800,
          damping: 30,
        }}
      />

      {/* White dot cursor */}
      <motion.div
        className="fixed top-0 left-0 rounded-full pointer-events-none z-[10000] bg-white"
        style={{
          x: mousePosition.x - 4,
          y: mousePosition.y - 4,
          height: cursorVariant === "click" ? 6 : 8,
          width: cursorVariant === "click" ? 6 : 8,
          opacity: cursorVariant === "click" ? 0.8 : 1,
          boxShadow: "0 0 5px rgba(255, 255, 255, 0.5)",
        }}
        transition={{
          type: "spring",
          mass: 0.2,
          stiffness: 1000,
          damping: 30,
        }}
      />

      {/* Text indicator for view state */}
      {cursorVariant === "view" && (
        <motion.div
          className="fixed top-0 left-0 pointer-events-none z-[9999] text-white text-xs font-medium bg-[#0E0E0E]/70 px-2 py-1 rounded"
          style={{
            x: mousePosition.x + 12,
            y: mousePosition.y - 10,
          }}
          transition={{
            type: "spring",
            mass: 0.2,
            stiffness: 1000,
            damping: 30,
          }}
        >
          View
        </motion.div>
      )}
    </>
  )
}

