"use client"

import type React from "react"

import { useRef } from "react"
import { motion, useTransform, useScroll } from "framer-motion"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ChevronDown } from "lucide-react"
import { TypeAnimation } from "react-type-animation"

export default function HeroSection() {
  const heroRef = useRef(null)
  const { scrollYProgress } = useScroll()
  const heroY = useTransform(scrollYProgress, [0, 0.2], [0, -100])

  const handleScrollToProjects = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault()
    document.getElementById("projects")?.scrollIntoView({ behavior: "smooth" })
  }

  return (
    <section
      ref={heroRef}
      className="relative min-h-screen flex flex-col items-center justify-center px-4 overflow-hidden"
    >
      <motion.div className="container relative z-10 max-w-5xl mx-auto text-center" style={{ y: heroY }}>
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="mb-6"
        >
          <span className="inline-block text-sm font-medium text-[#BC9862] px-3 py-1 border border-[#BC9862]/30 rounded-full mb-4">
            Welcome to my creative playground
          </span>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.5 }}
          className="text-5xl md:text-7xl font-bold mb-6 text-[#BC9862]"
        >
          Hey, I'm <span>Narasimha Reddy Valam</span>
        </motion.h1>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 1 }}
          className="text-xl md:text-2xl mb-8 h-16"
        >
          <TypeAnimation
            sequence={[
              "Creative Automation",
              1000,
              "Designing Experiences, Not Just Interfaces",
              1000,
              "AI + No-Code + Vibes = Me",
              1000,
            ]}
            wrapper="span"
            speed={50}
            repeat={Number.POSITIVE_INFINITY}
            className="text-[#DAC5A7]"
          />
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1.5 }}
          className="flex flex-wrap justify-center gap-4"
        >
          <Button
            className="group relative overflow-hidden bg-[#BC9862] text-[#0E0E0E] hover:bg-[#BC9862]/90 px-8 py-6 text-lg"
            asChild
          >
            <Link href="#projects" onClick={handleScrollToProjects}>
              <span className="relative z-10">Explore My Work</span>
              <span className="absolute inset-0 w-full h-full bg-white/10 scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-left"></span>
            </Link>
          </Button>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 2 }}
          className="absolute bottom-10 left-1/2 transform -translate-x-1/2"
        >
          <div className="animate-bounce">
            <ChevronDown className="h-8 w-8 text-[#BC9862]" />
          </div>
        </motion.div>
      </motion.div>
    </section>
  )
}

