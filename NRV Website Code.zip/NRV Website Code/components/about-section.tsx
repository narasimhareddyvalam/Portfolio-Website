"use client"

import { useRef } from "react"
import { motion, useTransform, useScroll } from "framer-motion"
import Image from "next/image"
import { Badge } from "@/components/ui/badge"
import { Sparkles, Palette } from "lucide-react"

export default function AboutSection() {
  const aboutRef = useRef(null)
  const { scrollYProgress } = useScroll()
  const aboutY = useTransform(scrollYProgress, [0.5, 0.7], [100, 0])

  return (
    <section id="about" ref={aboutRef} className="relative py-32 bg-[#0E0E0E]/50">
      <motion.div className="container max-w-5xl mx-auto px-4" style={{ y: aboutY }}>
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true, margin: "-100px" }}
          className="mb-16 text-center"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6 text-[#BC9862]">Who's Valam?</h2>
        </motion.div>

        <div className="flex flex-col md:flex-row items-center gap-12">
          <motion.div
            className="md:w-1/3"
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true, margin: "-100px" }}
          >
            <div className="relative w-64 h-64 mx-auto">
              <div className="absolute inset-0 rounded-full bg-gradient-to-r from-[#BC9862] to-amber-500 blur-xl opacity-30 animate-pulse"></div>
              <div className="relative w-full h-full rounded-full overflow-hidden border-4 border-[#BC9862] shadow-xl">
                <Image src="/images/profile-photo.jpeg" alt="Valam" fill className="object-cover" priority />
              </div>

              {/* Floating elements around avatar */}
              <div className="absolute -top-4 -right-4 p-2 bg-[#0E0E0E] rounded-full shadow-lg animate-bounce-slow">
                <Sparkles className="h-6 w-6 text-[#BC9862]" />
              </div>
              <div className="absolute -bottom-2 -left-4 p-2 bg-[#0E0E0E] rounded-full shadow-lg animate-bounce-slow delay-150">
                <Palette className="h-6 w-6 text-amber-500" />
              </div>
            </div>
          </motion.div>

          <motion.div
            className="md:w-2/3"
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true, margin: "-100px" }}
          >
            <div className="space-y-6">
              <p className="text-2xl font-medium text-[#DAC5A7]">
                "I'm a creative technologist who bridges the gap between design and automation. I build digital
                experiences that don't just look good—they work hard."
              </p>
              <p className="text-lg text-[#DAC5A7]/80">
                With a background in both design and development, I've found my sweet spot in the no-code revolution. I
                believe in creating solutions that are both beautiful and functional, using the latest tools and
                technologies to bring ideas to life without unnecessary complexity.
              </p>
              <p className="text-lg text-[#DAC5A7]/80">
                When I'm not building digital products, you'll find me exploring new AI tools, mentoring aspiring
                creators, or thinking about how to make technology more human-centered.
              </p>

              <div className="pt-6">
                <h3 className="text-xl font-bold mb-4 text-[#BC9862]">Skills & Expertise</h3>
                <div className="flex flex-wrap gap-2">
                  {[
                    "Low-Code Development",
                    "Process Automation",
                    "CRM Configuration",
                    "Workflow Design",
                    "Business Process Modeling",
                    "AI Integration",
                  ].map((skill) => (
                    <Badge
                      key={skill}
                      className="bg-[#BC9862]/20 text-[#BC9862] hover:bg-[#BC9862]/30 px-3 py-1 text-sm"
                    >
                      {skill}
                    </Badge>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-xl font-bold mb-4 text-[#BC9862]">Tools I Love</h3>
                <div className="flex flex-wrap gap-2">
                  {["Pega", "Salesforce", "Midjourney", "Framer", "ChatGPT", "Airtable"].map((tool) => (
                    <Badge
                      key={tool}
                      className="bg-amber-900/20 text-amber-500 hover:bg-amber-900/30 px-3 py-1 text-sm"
                    >
                      {tool}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </motion.div>
    </section>
  )
}

