"use client"

import { useRef } from "react"
import { motion, useTransform, useScroll } from "framer-motion"
import { Wand2, Zap, Sparkles, Palette, Lightbulb, Layers } from "lucide-react"
import ServiceCard from "@/components/service-card"

export default function ServicesSection() {
  const servicesRef = useRef(null)
  const { scrollYProgress } = useScroll()
  const servicesY = useTransform(scrollYProgress, [0.1, 0.3], [100, 0])

  const services = [
    {
      id: 1,
      title: "No-Code Wizardry",
      description: "Building powerful solutions without writing a single line of code.",
      icon: <Wand2 className="h-10 w-10" />,
      color: "from-[#BC9862] to-amber-500",
    },
    {
      id: 2,
      title: "Automation Architecture",
      description: "Designing systems that work while you sleep and scale while you sip coffee.",
      icon: <Zap className="h-10 w-10" />,
      color: "from-amber-500 to-orange-500",
    },
    {
      id: 3,
      title: "AI-Enhanced Creativity",
      description: "Leveraging artificial intelligence to amplify human creativity, not replace it.",
      icon: <Sparkles className="h-10 w-10" />,
      color: "from-orange-500 to-rose-500",
    },
    {
      id: 4,
      title: "Experience Design",
      description: "Crafting digital journeys that feel like magic, not just interfaces.",
      icon: <Palette className="h-10 w-10" />,
      color: "from-rose-500 to-pink-500",
    },
    {
      id: 5,
      title: "Generative AI for Smart UX",
      description: "Designing human-friendly workflows with AI insight.",
      icon: <Lightbulb className="h-10 w-10" />,
      color: "from-pink-500 to-purple-500",
    },
    {
      id: 6,
      title: "CRM & Platform Integration",
      description: "Seamlessly connecting systems for unified customer experiences.",
      icon: <Layers className="h-10 w-10" />,
      color: "from-purple-500 to-blue-500",
    },
  ]

  return (
    <section id="services" ref={servicesRef} className="relative py-32">
      <motion.div className="container max-w-6xl mx-auto px-4" style={{ y: servicesY }}>
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true, margin: "-100px" }}
          className="mb-16 text-center"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6 text-[#BC9862]">Things I Make Magic With</h2>
          <p className="text-xl max-w-2xl mx-auto text-[#DAC5A7]/80">
            Transforming ideas into experiences that captivate, engage, and inspire action.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={service.id}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true, margin: "-50px" }}
            >
              <ServiceCard service={service} />
            </motion.div>
          ))}
        </div>
      </motion.div>
    </section>
  )
}

