"use client"

import { useEffect } from "react"
import confetti from "canvas-confetti"

export default function EasterEgg() {
  useEffect(() => {
    // Space bar easter egg
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === "Space" && e.target === document.body) {
        e.preventDefault() // Prevent page scroll
        document.body.classList.add("easter-egg-active")
      }
    }

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.code === "Space") {
        document.body.classList.remove("easter-egg-active")
      }
    }

    // Konami code easter egg
    const konamiCode = [
      "ArrowUp",
      "ArrowUp",
      "ArrowDown",
      "ArrowDown",
      "ArrowLeft",
      "ArrowRight",
      "ArrowLeft",
      "ArrowRight",
      "b",
      "a",
    ]
    let konamiIndex = 0

    // Matrix code - type "matrix"
    const matrixCode = ["m", "a", "t", "r", "i", "x"]
    let matrixIndex = 0

    // Disco mode - type "disco"
    const discoCode = ["d", "i", "s", "c", "o"]
    let discoIndex = 0

    // Fireworks - type "boom"
    const fireworksCode = ["b", "o", "o", "m"]
    let fireworksIndex = 0

    // Spin - type "spin"
    const spinCode = ["s", "p", "i", "n"]
    let spinIndex = 0

    // Shake - type "shake"
    const shakeCode = ["s", "h", "a", "k", "e"]
    let shakeIndex = 0

    const handleKonami = (e: KeyboardEvent) => {
      // Konami code
      if (e.key === konamiCode[konamiIndex]) {
        konamiIndex++
        if (konamiIndex === konamiCode.length) {
          activateKonamiEasterEgg()
          konamiIndex = 0
        }
      } else {
        konamiIndex = 0
      }

      // Matrix code
      if (e.key.toLowerCase() === matrixCode[matrixIndex]) {
        matrixIndex++
        if (matrixIndex === matrixCode.length) {
          activateMatrixEffect()
          matrixIndex = 0
        }
      } else {
        matrixIndex = 0
      }

      // Disco code
      if (e.key.toLowerCase() === discoCode[discoIndex]) {
        discoIndex++
        if (discoIndex === discoCode.length) {
          activateDiscoMode()
          discoIndex = 0
        }
      } else {
        discoIndex = 0
      }

      // Fireworks code
      if (e.key.toLowerCase() === fireworksCode[fireworksIndex]) {
        fireworksIndex++
        if (fireworksIndex === fireworksCode.length) {
          activateFireworks()
          fireworksIndex = 0
        }
      } else {
        fireworksIndex = 0
      }

      // Spin code
      if (e.key.toLowerCase() === spinCode[spinIndex]) {
        spinIndex++
        if (spinIndex === spinCode.length) {
          activateSpinEffect()
          spinIndex = 0
        }
      } else {
        spinIndex = 0
      }

      // Shake code
      if (e.key.toLowerCase() === shakeCode[shakeIndex]) {
        shakeIndex++
        if (shakeIndex === shakeCode.length) {
          activateShakeEffect()
          shakeIndex = 0
        }
      } else {
        shakeIndex = 0
      }
    }

    const activateKonamiEasterEgg = () => {
      document.body.classList.add("konami-active")
      setTimeout(() => {
        document.body.classList.remove("konami-active")
      }, 5000)
    }

    const activateMatrixEffect = () => {
      document.body.classList.add("matrix-effect")

      // Create falling characters
      const container = document.createElement("div")
      container.className = "matrix-container"
      document.body.appendChild(container)

      for (let i = 0; i < 100; i++) {
        const character = document.createElement("div")
        character.className = "matrix-character"
        character.style.left = `${Math.random() * 100}vw`
        character.style.animationDuration = `${Math.random() * 5 + 2}s`
        character.style.animationDelay = `${Math.random() * 2}s`
        character.textContent = String.fromCharCode(0x30a0 + Math.random() * 96)
        container.appendChild(character)
      }

      setTimeout(() => {
        document.body.classList.remove("matrix-effect")
        document.body.removeChild(container)
      }, 8000)
    }

    const activateDiscoMode = () => {
      document.body.classList.add("disco-mode")

      const colors = ["#ff0000", "#ff7f00", "#ffff00", "#00ff00", "#0000ff", "#4b0082", "#9400d3"]
      let colorIndex = 0

      const interval = setInterval(() => {
        document.body.style.backgroundColor = colors[colorIndex]
        colorIndex = (colorIndex + 1) % colors.length
      }, 200)

      setTimeout(() => {
        clearInterval(interval)
        document.body.classList.remove("disco-mode")
        document.body.style.backgroundColor = ""
      }, 5000)
    }

    const activateFireworks = () => {
      const duration = 5000
      const animationEnd = Date.now() + duration
      const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 9999 }

      function randomInRange(min: number, max: number) {
        return Math.random() * (max - min) + min
      }

      const interval: any = setInterval(() => {
        const timeLeft = animationEnd - Date.now()

        if (timeLeft <= 0) {
          return clearInterval(interval)
        }

        const particleCount = 50 * (timeLeft / duration)

        // since particles fall down, start a bit higher than random
        confetti(
          Object.assign({}, defaults, {
            particleCount,
            origin: { x: randomInRange(0.1, 0.3), y: Math.random() - 0.2 },
            colors: ["#ff0000", "#ff7f00", "#ffff00"],
          }),
        )
        confetti(
          Object.assign({}, defaults, {
            particleCount,
            origin: { x: randomInRange(0.7, 0.9), y: Math.random() - 0.2 },
            colors: ["#00ff00", "#0000ff", "#9400d3"],
          }),
        )
      }, 250)
    }

    const activateSpinEffect = () => {
      document.body.classList.add("spin-effect")
      setTimeout(() => {
        document.body.classList.remove("spin-effect")
      }, 3000)
    }

    const activateShakeEffect = () => {
      document.body.classList.add("shake-effect")
      setTimeout(() => {
        document.body.classList.remove("shake-effect")
      }, 1000)
    }

    window.addEventListener("keydown", handleKeyDown)
    window.addEventListener("keyup", handleKeyUp)
    window.addEventListener("keydown", handleKonami)

    return () => {
      window.removeEventListener("keydown", handleKeyDown)
      window.removeEventListener("keyup", handleKeyUp)
      window.removeEventListener("keydown", handleKonami)
    }
  }, [])

  return null
}

