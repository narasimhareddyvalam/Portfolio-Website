"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"

// Components
import CustomCursor from "@/components/custom-cursor"
import FloatingElements from "@/components/floating-elements"
import EasterEgg from "@/components/easter-egg"
import ParticlesBackground from "@/components/particles-background"
import PageLoader from "@/components/page-loader"
import Navbar from "@/components/navbar"
import HeroSection from "@/components/hero-section"
import ServicesSection from "@/components/services-section"
import ProjectsSection from "@/components/projects-section"
import CertificationsSection from "@/components/certifications-section"
import AboutSection from "@/components/about-section"
import ContactSection from "@/components/contact-section"
import Footer from "@/components/footer"
import SurpriseButton from "@/components/surprise-button"

export default function Portfolio() {
  const [isLoading, setIsLoading] = useState(true)
  const [scrollY, setScrollY] = useState(0)
  const [cursorReady, setCursorReady] = useState(false)

  // Surprise me quotes
  const surpriseQuotes = [
    "I've automated over 50 business processes that save companies thousands of hours annually.",
    "My design philosophy: If it's not both beautiful AND functional, it's not finished.",
    "I once built an entire HR system in 48 hours during a hackathon—and won first place.",
    "I believe AI should enhance human creativity, not replace it.",
    "My secret talent: I can explain complex technical concepts to anyone, even my grandmother.",
    "I've trained AI models to recognize patterns that humans typically miss in workflow analysis.",
  ]

  useEffect(() => {
    // Simulate loading time
    const timer = setTimeout(() => {
      setIsLoading(false)
    }, 3500)

    // Scroll listener for parallax effects
    const handleScroll = () => {
      setScrollY(window.scrollY)
    }
    window.addEventListener("scroll", handleScroll)

    // Ensure cursor is initialized after a short delay
    const cursorTimer = setTimeout(() => {
      setCursorReady(true)
    }, 500)

    return () => {
      clearTimeout(timer)
      clearTimeout(cursorTimer)
      window.removeEventListener("scroll", handleScroll)
    }
  }, [])

  const triggerSurprise = () => {
    // Random number between 0 and 5
    const surpriseType = Math.floor(Math.random() * 6)

    switch (surpriseType) {
      case 0:
        // This is now handled in the SurpriseButton component
        break
      case 1:
        // Random quote
        const randomQuote = surpriseQuotes[Math.floor(Math.random() * surpriseQuotes.length)]
        toast({
          title: "Fun Fact About Me",
          description: randomQuote,
          duration: 5000,
        })
        break
      case 2:
        // Background theme animation
        document.body.classList.add("theme-pulse")
        setTimeout(() => {
          document.body.classList.remove("theme-pulse")
        }, 3000)
        break
      case 3:
        // AI chip glow effect
        const aiChip = document.createElement("div")
        aiChip.className = "ai-chip-glow"
        aiChip.innerHTML = `<svg viewBox="0 0 24 24" width="80" height="80" stroke="currentColor" strokeWidth="1" fill="none" strokeLinecap="round" strokeLinejoin="round"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"></path></svg>`
        document.body.appendChild(aiChip)
        setTimeout(() => {
          document.body.removeChild(aiChip)
        }, 4000)
        break
      case 4:
        // Bouncing icon effect
        const iconContainer = document.createElement("div")
        iconContainer.className = "bouncing-icon"
        iconContainer.innerHTML = `<svg viewBox="0 0 24 24" width="60" height="60" stroke="#BC9862" strokeWidth="2" fill="none"><circle cx="12" cy="12" r="10"></circle><path d="M8 14s1.5 2 4 2 4-2 4-2"></path><line x1="9" y1="9" x2="9.01" y2="9"></line><line x1="15" y1="9" x2="15.01" y2="9"></line></svg>`
        document.body.appendChild(iconContainer)
        setTimeout(() => {
          document.body.removeChild(iconContainer)
        }, 3000)
        break
      case 5:
        // Matrix-like code rain effect
        document.body.classList.add("code-rain")
        setTimeout(() => {
          document.body.classList.remove("code-rain")
        }, 5000)
        break
    }
  }

  if (isLoading) {
    return <PageLoader />
  }

  return (
    <>
      {cursorReady && <CustomCursor />}
      <EasterEgg />
      <Toaster />

      <div className="relative min-h-screen bg-[#0E0E0E] text-[#DAC5A7] overflow-hidden">
        {/* Surprise Me button */}
        <SurpriseButton triggerSurprise={triggerSurprise} />

        {/* Progress bar */}
        <motion.div
          className="fixed top-0 left-0 right-0 h-1 bg-gradient-to-r from-[#BC9862] via-amber-500 to-[#BC9862] z-50 origin-left"
          style={{ scaleX: scrollY / (document.body.scrollHeight - window.innerHeight) || 0 }}
        />

        {/* Background elements */}
        <div className="fixed inset-0 z-0">
          <ParticlesBackground />
          <FloatingElements />
        </div>

        {/* Header */}
        <Navbar />

        <main>
          {/* Hero Section */}
          <HeroSection />

          {/* Services Section */}
          <ServicesSection />

          {/* Projects Section */}
          <ProjectsSection />

          {/* Certifications Section */}
          <CertificationsSection />

          {/* About Section */}
          <AboutSection />

          {/* Contact Section */}
          <ContactSection />
        </main>

        {/* Footer */}
        <Footer triggerSurprise={triggerSurprise} />
      </div>
    </>
  )
}

